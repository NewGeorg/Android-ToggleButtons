package com.example.georg.testtablelayout;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final ToggleButton carrotButton = (ToggleButton)findViewById(R.id.carrotToggleButton);
        carrotButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    carrotButton.setBackgroundResource(R.drawable.carrot1);

                } else {
                    carrotButton.setBackgroundResource(R.drawable.carrot);
                }
            }
        });

        final ToggleButton onionButton = (ToggleButton)findViewById(R.id.onionToggleButton);
        onionButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    onionButton.setBackgroundResource(R.drawable.onion1);
                } else {
                    onionButton.setBackgroundResource(R.drawable.onion);
                }
            }
        });

        final ToggleButton tomatoButton = (ToggleButton)findViewById(R.id.tomatoToggleButton);
        tomatoButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    tomatoButton.setBackgroundResource(R.drawable.tomato1);
                } else {
                    tomatoButton.setBackgroundResource(R.drawable.tomato);
                }
            }
        });

        final ToggleButton breadButton = (ToggleButton)findViewById(R.id.breadToggleButton);
        breadButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    breadButton.setBackgroundResource(R.drawable.bread1);
                } else {
                    breadButton.setBackgroundResource(R.drawable.bread);
                }
            }
        });

        final ToggleButton oilButton = (ToggleButton)findViewById(R.id.oilToggleButton);
        oilButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    oilButton.setBackgroundResource(R.drawable.oil1);
                } else {
                    oilButton.setBackgroundResource(R.drawable.oil);
                }
            }
        });

        final ToggleButton garlicButton = (ToggleButton)findViewById(R.id.garlicToggleButton);
        garlicButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    garlicButton.setBackgroundResource(R.drawable.garlic1);
                } else {
                    garlicButton.setBackgroundResource(R.drawable.garlic);
                }
            }
        });

        final ToggleButton butterButton = (ToggleButton)findViewById(R.id.butterToggleButton);
        butterButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    butterButton.setBackgroundResource(R.drawable.butter1);
                } else {
                    butterButton.setBackgroundResource(R.drawable.butter);
                }
            }
        });

        final ToggleButton cheeseButton = (ToggleButton)findViewById(R.id.cheeseToggleButton);
        cheeseButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    cheeseButton.setBackgroundResource(R.drawable.cheese1);
                } else {
                    cheeseButton.setBackgroundResource(R.drawable.cheese);
                }
            }
        });

        final ToggleButton chickenButton = (ToggleButton)findViewById(R.id.chickenToggleButton);
        chickenButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    chickenButton.setBackgroundResource(R.drawable.chicken1);
                } else {
                    chickenButton.setBackgroundResource(R.drawable.chicken);
                }
            }
        });

        final ToggleButton chivesButton = (ToggleButton)findViewById(R.id.chivesToggleButton);
        chivesButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    chivesButton.setBackgroundResource(R.drawable.chives1);
                } else {
                    chivesButton.setBackgroundResource(R.drawable.chives);
                }
            }
        });

        final ToggleButton eggButton = (ToggleButton)findViewById(R.id.eggToggleButton);
        eggButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    eggButton.setBackgroundResource(R.drawable.egg1);
                } else {
                    eggButton.setBackgroundResource(R.drawable.egg);
                }
            }
        });

        final ToggleButton gingerButton = (ToggleButton)findViewById(R.id.gingerToggleButton);
        gingerButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    gingerButton.setBackgroundResource(R.drawable.ginger1);
                } else {
                    gingerButton.setBackgroundResource(R.drawable.ginger);
                }
            }
        });

        final ToggleButton lemonButton = (ToggleButton)findViewById(R.id.lemonToggleButton);
        lemonButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    lemonButton.setBackgroundResource(R.drawable.lemon1);
                } else {
                    lemonButton.setBackgroundResource(R.drawable.lemon);
                }
            }
        });

        final ToggleButton pepperButton = (ToggleButton)findViewById(R.id.pepperToggleButton);
        pepperButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    pepperButton.setBackgroundResource(R.drawable.pepper1);
                } else {
                    pepperButton.setBackgroundResource(R.drawable.pepper);
                }
            }
        });

        final ToggleButton saltButton = (ToggleButton)findViewById(R.id.saltToggleButton);
        saltButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    saltButton.setBackgroundResource(R.drawable.salt1);
                } else {
                    saltButton.setBackgroundResource(R.drawable.salt);
                }
            }
        });

        final ToggleButton hamButton = (ToggleButton)findViewById(R.id.hamToggleButton);
        hamButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    hamButton.setBackgroundResource(R.drawable.ham1);
                } else {
                    hamButton.setBackgroundResource(R.drawable.ham);
                }
            }
        });
        final ToggleButton honeyButton = (ToggleButton)findViewById(R.id.honeyToggleButton);
        honeyButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    honeyButton.setBackgroundResource(R.drawable.honey1);
                } else {
                    honeyButton.setBackgroundResource(R.drawable.honey);
                }
            }
        });

        final ToggleButton redcabbageButton = (ToggleButton)findViewById(R.id.redcabbageToggleButton);
        redcabbageButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    redcabbageButton.setBackgroundResource(R.drawable.redcabbage1);
                } else {
                    redcabbageButton.setBackgroundResource(R.drawable.redcabbage);
                }
            }
        });

        final ToggleButton spinachButton = (ToggleButton)findViewById(R.id.spinachToggleButton);
        spinachButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    spinachButton.setBackgroundResource(R.drawable.spinach1);
                } else {
                    spinachButton.setBackgroundResource(R.drawable.spinach);
                }
            }
        });

        final ToggleButton spaghettiButton = (ToggleButton)findViewById(R.id.spaghettiToggleButton);
        spaghettiButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    spaghettiButton.setBackgroundResource(R.drawable.spaguetti1);
                } else {
                    spaghettiButton.setBackgroundResource(R.drawable.spaguetti);
                }
            }
        });

        final ToggleButton toadstoolButton = (ToggleButton)findViewById(R.id.toadstoolToggleButton);
        toadstoolButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    toadstoolButton.setBackgroundResource(R.drawable.toadstool1);
                } else {
                    toadstoolButton.setBackgroundResource(R.drawable.toadstool);
                }
            }
        });

        final ToggleButton sausageButton = (ToggleButton)findViewById(R.id.sausageToggleButton);
        sausageButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    sausageButton.setBackgroundResource(R.drawable.sausage1);
                } else {
                    sausageButton.setBackgroundResource(R.drawable.sausage);
                }
            }
        });

    }
}
